x = [0 0 1 1; 0 1 0 1];
t = [0 1 1 1];
net = perceptron;
net = train(net,x,t);
view(net)
y = net(x);

[accu,majB,ratio] = ML_Accuracy(t,y);
The primary code used to test the algorithms I reported is as follows

SVMTest.m
BasicPerceptron.m
AveragePerceptron.m
AggressivePerceptron.m
SVM_Over_Test.m
SVM_Under_Test.m
ReadTimeTest.m

Executing any of these in the MATLAB environment will start cross-validation
and will ultimately report the statistics I include in my report. 